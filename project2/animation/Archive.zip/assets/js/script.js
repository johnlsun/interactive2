// $('.go').click(function() {
//     $('.announcement').toggle();
// });

// $('.shellsa').hover(function() {
//      $('.bdscale').fadeIn(); 
// }     
// });

// $('.octogon1 bdscale').mouseleave(function() {
//      $('.bdscale').fadeOut();
// });

// $('button').click(function() {
//   $('p').toggle();
// });


$('.shellsa').hover(function() {
     $('.a').fadeIn(); 
});
$('.shellsa').mouseleave(function() {
     $('.a').fadeOut(); 
});

$('.shellsb').hover(function() {
     $('.b').fadeIn(); 
});
$('.shellsb').mouseleave(function() {
     $('.b').fadeOut(); 
}); 

$('.shellsc').hover(function() {
     $('.c').fadeIn(); 
});
$('.shellsc').mouseleave(function() {
     $('.c').fadeOut(); 
});
$('.shellsd').hover(function() {
     $('.d').fadeIn(); 
});
$('.shellsd').mouseleave(function() {
     $('.d').fadeOut(); 
});
$('.shellse').hover(function() {
     $('.e').fadeIn(); 
});
$('.shellse').mouseleave(function() {
     $('.e').fadeOut(); 
});
$('.shellsf').hover(function() {
     $('.f').fadeIn(); 
});
$('.shellsf').mouseleave(function() {
     $('.f').fadeOut(); 
});
$('.shellsg').hover(function() {
     $('.g').fadeIn(); 
});
$('.shellsg').mouseleave(function() {
     $('.g').fadeOut(); 
});
$('.shellsh').hover(function() {
     $('.h').fadeIn(); 
});
$('.shellsh').mouseleave(function() {
     $('.h').fadeOut(); 
});
$('.shellsi').hover(function() {
     $('.i').fadeIn(); 
});
$('.shellsi').mouseleave(function() {
     $('.i').fadeOut(); 
});
$('.shellsj').hover(function() {
     $('.j').fadeIn(); 
});
$('.shellsj').mouseleave(function() {
     $('.j').fadeOut(); 
});
$('.shellsk').hover(function() {
     $('.k').fadeIn(); 
});
$('.shellsk').mouseleave(function() {
     $('.k').fadeOut(); 
});
$('.shellsl').hover(function() {
     $('.l').fadeIn(); 
});
$('.shellsl').mouseleave(function() {
     $('.l').fadeOut(); 
});
$('.shellsm').hover(function() {
     $('.m').fadeIn(); 
});
$('.shellsm').mouseleave(function() {
     $('.m').fadeOut(); 
});
$('.shellsn').hover(function() {
     $('.n').fadeIn(); 
});
$('.shellsn').mouseleave(function() {
     $('.n').fadeOut(); 
});
$('.shellso').hover(function() {
     $('.o').fadeIn(); 
});
$('.shellso').mouseleave(function() {
     $('.o').fadeOut(); 
});
$('.shellsp').hover(function() {
     $('.p').fadeIn(); 
});
$('.shellsp').mouseleave(function() {
     $('.p').fadeOut(); 
});
$('.shellsq').hover(function() {
     $('.q').fadeIn(); 
});
$('.shellsq').mouseleave(function() {
     $('.q').fadeOut(); 
});
$('.shellsr').hover(function() {
     $('.r').fadeIn(); 
});
$('.shellsr').mouseleave(function() {
     $('.r').fadeOut(); 
});
$('.shellss').hover(function() {
     $('.s').fadeIn(); 
});
$('.shellss').mouseleave(function() {
     $('.s').fadeOut(); 
});
$('.shellst').hover(function() {
     $('.t').fadeIn(); 
});
$('.shellst').mouseleave(function() {
     $('.t').fadeOut(); 
});
$('.shellsu').hover(function() {
     $('.u').fadeIn(); 
});
$('.shellsu').mouseleave(function() {
     $('.u').fadeOut(); 
});
$('.shellsv').hover(function() {
     $('.v').fadeIn(); 
});
$('.shellsv').mouseleave(function() {
     $('.v').fadeOut(); 
});
$('.shellsw').hover(function() {
     $('.w').fadeIn(); 
});
$('.shellsw').mouseleave(function() {
     $('.w').fadeOut(); 
});
$('.shellsx').hover(function() {
     $('.x').fadeIn(); 
});
$('.shellsx').mouseleave(function() {
     $('.x').fadeOut(); 
});
$('.shellsy').hover(function() {
     $('.y').fadeIn(); 
});
$('.shellsy').mouseleave(function() {
     $('.y').fadeOut(); 
});
$('.shellsz').hover(function() {
     $('.z').fadeIn(); 
});
$('.shellsz').mouseleave(function() {
     $('.z').fadeOut(); 
});
$('.shellszero').hover(function() {
     $('.zero').fadeIn(); 
});
$('.shellszero').mouseleave(function() {
     $('.zero').fadeOut(); 
});
$('.shellsone').hover(function() {
     $('.one').fadeIn(); 
});
$('.shellsone').mouseleave(function() {
     $('.one').fadeOut(); 
});
$('.shellstwo').hover(function() {
     $('.two').fadeIn(); 
});
$('.shellstwo').mouseleave(function() {
     $('.two').fadeOut(); 
});
$('.shellsthree').hover(function() {
     $('.three').fadeIn(); 
});
$('.shellsthree').mouseleave(function() {
     $('.three').fadeOut(); 
});
$('.shellsfour').hover(function() {
     $('.four').fadeIn(); 
});
$('.shellsfour').mouseleave(function() {
     $('.four').fadeOut(); 
});
$('.shellsfive').hover(function() {
     $('.five').fadeIn(); 
});
$('.shellsfive').mouseleave(function() {
     $('.five').fadeOut(); 
});
$('.shellssix').hover(function() {
     $('.six').fadeIn(); 
});
$('.shellssix').mouseleave(function() {
     $('.six').fadeOut(); 
});
$('.shellsseven').hover(function() {
     $('.seven').fadeIn(); 
});
$('.shellsseven').mouseleave(function() {
     $('.seven').fadeOut(); 
});
$('.shellseight').hover(function() {
     $('.eight').fadeIn(); 
});
$('.shellseight').mouseleave(function() {
     $('.eight').fadeOut(); 
});
$('.shellsnine').hover(function() {
     $('.nine').fadeIn(); 
});
$('.shellsnine').mouseleave(function() {
     $('.nine').fadeOut(); 
});
$('.shellsquestion').hover(function() {
     $('.question').fadeIn(); 
});
$('.shellsquestion').mouseleave(function() {
     $('.question').fadeOut(); 
});
$('.shellsexclamation').hover(function() {
     $('.exclamation').fadeIn(); 
});
$('.shellsexclamation').mouseleave(function() {
     $('.exclamation').fadeOut(); 
});
$('.shellscomma').hover(function() {
     $('.comma').fadeIn(); 
});
$('.shellscomma').mouseleave(function() {
     $('.comma').fadeOut(); 
});
$('.shellsquote').hover(function() {
     $('.quote').fadeIn(); 
});
$('.shellsquote').mouseleave(function() {
     $('.quote').fadeOut(); 
});
$('.shellsquote1').hover(function() {
     $('.quote1').fadeIn(); 
});
$('.shellsquote1').mouseleave(function() {
     $('.quote1').fadeOut(); 
});
$('.shellsperiod').hover(function() {
     $('.period').fadeIn(); 
});
$('.shellsperiod').mouseleave(function() {
     $('.period').fadeOut(); 
});